<div class="copyrights" style="background-color: rgba(18, 124, 255, 0.79);border-radius: 25px">
	 <h3>Trường Đại học Dân lập Hải Phòng - Haiphong Private University </h3>
		<h4>Địa chỉ: Số 36 - Đường Dân Lập - Phường Dư Hàng Kênh - Quận Lê Chân - TP Hải Phòng</h4>
		<h4>Điện thoại: 0225 3740577 - 0225 3833802 - 0225 3740578 Fax: 0225.3740476 Email: webmaster@hpu.edu.vn </h4>
		<p>Phát triển bởi Trung tâm Thông tin thư viện </p>
		</div>	