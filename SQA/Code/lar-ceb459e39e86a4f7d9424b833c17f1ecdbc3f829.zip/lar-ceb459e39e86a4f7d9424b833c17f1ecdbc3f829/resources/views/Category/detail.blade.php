@extends("layouts.main")
@section('content')
    <h1>{{$category->name}}</h1>
    <img src="https://cdn4.iconfinder.com/data/icons/iconsimple-logotypes/512/apple-128.png"/>
@endsection