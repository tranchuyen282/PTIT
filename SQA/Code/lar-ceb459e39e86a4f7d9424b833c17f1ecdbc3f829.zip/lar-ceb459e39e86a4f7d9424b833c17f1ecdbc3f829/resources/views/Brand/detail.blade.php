@extends("layouts.main")
@section('content')
    <h1>{{$brand->name}}</h1>
@endsection
