@extends("layouts.main")

@section("content")
    <h1>{{$product->name}}</h1>

@endsection