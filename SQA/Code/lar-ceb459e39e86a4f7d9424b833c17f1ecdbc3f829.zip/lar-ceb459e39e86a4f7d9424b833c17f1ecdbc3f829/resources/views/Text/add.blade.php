@extends('layouts.main')
@section('content')
    <h1>Sự khác nhau giữa 2 cái này</h1>
    {{ $text }}<br/>
    {!!$text!!};

@endsection