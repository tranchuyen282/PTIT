<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DangKyHocPhan extends Model
{
    protected $table = 'dang_ky_hoc_phan';
}
