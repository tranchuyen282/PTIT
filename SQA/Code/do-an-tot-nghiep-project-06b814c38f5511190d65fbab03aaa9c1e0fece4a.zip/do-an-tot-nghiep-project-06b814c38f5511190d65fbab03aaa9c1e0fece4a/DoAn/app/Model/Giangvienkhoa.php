<?php
class Giangvienkhoa extends AppModel{
	var $name="Giangvienkhoa";	
}
?>