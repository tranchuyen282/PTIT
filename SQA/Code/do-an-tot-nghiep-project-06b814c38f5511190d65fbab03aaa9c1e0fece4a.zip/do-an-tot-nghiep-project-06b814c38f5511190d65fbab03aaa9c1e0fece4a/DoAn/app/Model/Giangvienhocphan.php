<?php
class Giangvienhocphan extends AppModel{
	var $name="Giangvienhocphan";
	
}
?>