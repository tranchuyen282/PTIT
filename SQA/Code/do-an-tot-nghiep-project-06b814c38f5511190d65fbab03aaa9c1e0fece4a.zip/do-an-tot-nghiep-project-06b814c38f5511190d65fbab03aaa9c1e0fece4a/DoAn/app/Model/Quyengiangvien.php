<?php
class Quyengiangvien extends AppModel{
	var $name="Quyengiangvien";
}
?>