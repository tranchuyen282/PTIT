<?php
	class Thongbao extends AppModel{
		var $name="Thongbao";
	}
?>