<?php
	class Lichthi extends AppModel{
		var $name="Lichthi";
	}
?>