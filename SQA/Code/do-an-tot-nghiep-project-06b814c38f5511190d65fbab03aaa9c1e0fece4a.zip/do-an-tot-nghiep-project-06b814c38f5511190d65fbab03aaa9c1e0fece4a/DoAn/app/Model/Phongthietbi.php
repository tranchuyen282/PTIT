<?php
class Phongthietbi extends AppModel{
	var $name="Phongthietbi";
}
?>