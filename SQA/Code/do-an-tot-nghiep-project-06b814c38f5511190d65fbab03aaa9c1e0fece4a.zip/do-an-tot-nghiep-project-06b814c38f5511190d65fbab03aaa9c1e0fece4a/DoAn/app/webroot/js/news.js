$( document ).ready( function() {
	$( 'textarea#noidung_news' ).ckeditor();
} );