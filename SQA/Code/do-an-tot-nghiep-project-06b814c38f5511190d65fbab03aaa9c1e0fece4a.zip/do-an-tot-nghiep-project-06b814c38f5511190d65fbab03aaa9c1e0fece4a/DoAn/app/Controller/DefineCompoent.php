<?php
class DefineCompoent{
	function sotiet($tinchi,$sotuan){
		$sumtiet=$tinchi*15;
		return round($sumtiet/$sotuan);
	}
	function creatlichGiangday($arrPhong,$arrlopHp,$arrgv ){
		
	}
}